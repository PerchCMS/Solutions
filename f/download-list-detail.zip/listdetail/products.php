<?php include('perch/runtime.php'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
	<title>List Detail Example Page</title>
</head>
<body>

<?php

     perch_content_create('Products', array(
          'template'  => 'product_detail.html',
          'multiple'  => true,
          'edit-mode' => 'listdetail',
     ));


     if (perch_get('s')) {

          // Detail mode
          perch_content_custom('Products', array(
               'template' => 'product_detail.html',
               'filter'   => 'slug',
               'match'    => 'eq',
               'value'    => perch_get('s'),
               'count'    => 1,
          )); 

     } else {

          // List mode
          perch_content_custom('Products', array(
               'template' => 'product_listing.html',
          )); 
     }

?>

</body>
</html>

