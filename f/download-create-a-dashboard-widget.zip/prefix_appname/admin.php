<?php
   	if ($CurrentUser->logged_in()) {
   		$this->register_app('prefix_appname', 'App name', 1, 'App description', '1', false);
    	$this->require_version('prefix_appname', '2.0.8');
	}
?>