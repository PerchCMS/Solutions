<div class="widget">
  <h2>
    <?php echo $Lang->get('Title of your widget'); ?>
  </h2>
  <div class="bd">
	<p>Your content goes here.</p>	
  </div>
</div>